const fontSlider = document.getElementById('fontSizeRange');
const imgSlider = document.getElementById('imgSizeRange');
document.documentElement.style.setProperty('--font-size', fontSlider.value + 'px');
document.documentElement.style.setProperty('--img-size', imgSlider.value + 'px');

fontSlider.addEventListener('input', () => {
    document.documentElement.style.setProperty('--font-size', fontSlider.value + 'px');
});
imgSlider.addEventListener('input', () => {
    document.documentElement.style.setProperty('--img-size', imgSlider.value + 'px');
});

function checkAnswers() {
    let score = 0;
    const questions = document.querySelectorAll('.question');
    questions.forEach(q => {
    const selected = q.querySelector('button.selected');
    const correct = q.dataset.answer;
    if (selected && selected.classList.contains(correct)) {
        score++;
        selected.style.border = '2px solid green';
    } else if (selected) {
        selected.style.border = '2px solid red';
    }
    });
    document.getElementById('result').textContent = `You scored ${score} / ${questions.length}`;
}

function showAnswers() {
    const questions = document.querySelectorAll('.question');
    questions.forEach(q => {
    const correct = q.dataset.answer;
    q.querySelector('.' + correct).style.border = '2px dashed blue';
    });
}

function resetQuiz() {
    const buttons = document.querySelectorAll('.question button');
    buttons.forEach(b => {
    b.classList.remove('selected');
    b.style.border = 'none';
    });
    document.getElementById('result').textContent = '';
}

document.querySelectorAll('.question button').forEach(button => {
    button.addEventListener('click', () => {
    const parent = button.closest('.question');
    parent.querySelectorAll('button').forEach(b => b.classList.remove('selected'));
    button.classList.add('selected');
    });
});